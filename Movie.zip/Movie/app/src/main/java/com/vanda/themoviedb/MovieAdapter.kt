package com.vanda.themoviedb

class MovieAdapter {
}