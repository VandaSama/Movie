package com.vanda.themoviedb.model

class TV {
}