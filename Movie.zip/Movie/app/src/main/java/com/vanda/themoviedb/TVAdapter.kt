package com.vanda.themoviedb

class TVAdapter {
}