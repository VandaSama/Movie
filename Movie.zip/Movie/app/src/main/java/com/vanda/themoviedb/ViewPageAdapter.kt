package com.vanda.themoviedb

class ViewPageAdapter {
}