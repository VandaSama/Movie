package com.vanda.themoviedb.model

class MovieResponse {
}