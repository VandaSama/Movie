package com.vanda.themoviedb.model

class TVResponse {
}